# CasinoBot
## Telegram казино бот
### Установка
```
git clone https://github.com/0xSn1kky/tg_casinobot.git
```

**Установите модуль**
MacOS/Linux
```
pip3 install pyTelegramBotAPI
```
Windows
```
pip install pyTelegramBotAPI
```

**Откройте config.py и отредактируйте**
**Запустите main.py**
```
python main.py
```
**Фаил с базой данных будет создан автоматически**

### Список команд
/help - список команд
/bonus - получить бонус
/casino - играть в казино
/setmoney - установить кол-во денег (Только админу)
/stop - остановить бота (Только админу)


